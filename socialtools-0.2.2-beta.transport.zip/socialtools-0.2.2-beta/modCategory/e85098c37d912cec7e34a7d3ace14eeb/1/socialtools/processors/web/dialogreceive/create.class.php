<?php
/**
 * Create an Item
 */
class socDialogReciveCreateProcessor extends modObjectCreateProcessor {
	public $objectType = 'socDialogReceive';
	public $classKey = 'socDialogReceive';
	public $languageTopics = array('socialtools');

}

return 'socDialogReciveCreateProcessor';