<?php
require_once (dirname(dirname(__FILE__)) . '/socdialogreceive.class.php');
class socDialogReceive_mysql extends socDialogReceive {}