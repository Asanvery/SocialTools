<?php
class SocialToolsItem extends xPDOSimpleObject {}