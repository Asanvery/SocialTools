<?php
class socDialogReceive extends xPDOSimpleObject {}