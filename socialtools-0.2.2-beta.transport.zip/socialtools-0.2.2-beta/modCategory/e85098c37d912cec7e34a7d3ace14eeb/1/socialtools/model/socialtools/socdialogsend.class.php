<?php
class socDialogSend extends xPDOSimpleObject {}