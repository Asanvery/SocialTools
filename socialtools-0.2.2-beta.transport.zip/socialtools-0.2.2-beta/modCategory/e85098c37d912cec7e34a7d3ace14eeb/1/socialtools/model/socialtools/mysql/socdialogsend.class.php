<?php
require_once (dirname(dirname(__FILE__)) . '/socdialogsend.class.php');
class socDialogSend_mysql extends socDialogSend {}