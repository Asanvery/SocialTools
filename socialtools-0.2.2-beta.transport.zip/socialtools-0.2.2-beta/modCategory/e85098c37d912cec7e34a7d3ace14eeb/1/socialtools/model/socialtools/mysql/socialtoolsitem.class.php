<?php
require_once (dirname(dirname(__FILE__)) . '/socialtoolsitem.class.php');
class SocialToolsItem_mysql extends SocialToolsItem {}