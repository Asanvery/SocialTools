<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'socDialogReceive',
    1 => 'socDialogSend',
    2 => 'SocialToolsItem',
  ),
);