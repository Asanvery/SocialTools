<?php
$_lang['area_socialtools_main'] = 'Основные';
$_lang['area_socialtools_debug'] = 'Режим отладки';
$_lang['area_socialtools_message'] = 'Сообщения';
$_lang['setting_socialtools.css_use'] = 'Использовать CSS';
$_lang['setting_socialtools.css_use_desc'] = 'Подключать CSS по умолчанию';
$_lang['setting_socialtools.gravatar_use'] = 'Использовать Gravatar';
$_lang['setting_socialtools.gravatar_use_desc'] = 'Использовать для вывода аватаров сервис Gravatar, если нет, будет использовано поле photo из профиля пользователя MODX';
$_lang['setting_socialtools.frontend_css'] = 'Путь к CSS';
$_lang['setting_socialtools.frontend_css_desc'] = 'Относительный путь к CSS файлу';
$_lang['setting_socialtools.notify'] = 'Тип оповещения';
$_lang['setting_socialtools.notify_desc'] = 'Есть 2 вида оповещения, alertify и jgrowl';
$_lang['setting_socialtools.debug'] = 'Debug';
$_lang['setting_socialtools.deubg_desc'] = 'Режим отладки позволяет посылать сообщения самому себе';
$_lang['setting_socialtools.is_read'] = 'Плейсхолдер для непрочитанных сообщений';
$_lang['setting_socialtools.is_read_desc'] = 'Наименование плейсхолдера для отображения не прочтенных сообщений';
