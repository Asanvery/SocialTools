<?php

$_lang['socialtools_prop_tplFormCreate'] = 'Шаблон формы отправки сообщения';
$_lang['socialtools_prop_tplFormReadInbox'] = 'Шаблон  чтения входящих сообщения';
$_lang['socialtools_prop_tplFormReadOutbox'] = 'Шаблон  чтения исходящих сообщения';
$_lang['socialtools_list_prop_inboxTpl'] = 'Шаблон оформления строки вывода входящих сообщений';
$_lang['socialtools_list_prop_outboxTpl'] = 'Шаблон оформления строки вывода исходящих сообщений';
$_lang['socialtools_list_prop_limit'] = 'Лимит выборки результатов';
$_lang['socialtools_list_prop_offset'] = 'Пропуск результатов с начала выборки';
$_lang['socialtools_list_prop_sortby'] = 'Сортировка выборки';
$_lang['socialtools_list_prop_sortdir'] = 'Направление сортировки';
$_lang['socialtools_list_prop_action'] = 'Вывод входящих или исходящих сообщений';
$_lang['socialtools_list_prop_outputSeparator'] = 'Разделитель строк';
$_lang['socialtools_list_prop_totalVar'] = 'Плейсхолдер для общего значения результатов';



