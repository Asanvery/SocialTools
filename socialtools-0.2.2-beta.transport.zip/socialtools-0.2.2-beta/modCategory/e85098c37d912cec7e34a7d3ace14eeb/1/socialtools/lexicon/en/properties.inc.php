<?php

$_lang['socialtools_prop_tplFormCreate'] = 'Template form send';
$_lang['socialtools_prop_tplFormReadInbox'] = 'Template read inbox message';
$_lang['socialtools_prop_tplFormReadOutbox'] = 'Template read outbox message';
$_lang['socialtools_list_prop_inboxTpl'] = 'Template row inbox';
$_lang['socialtools_list_prop_outboxTpl'] = 'Template row outbox';
$_lang['socialtools_list_prop_limit'] = 'The number of results to limit';
$_lang['socialtools_list_prop_offset'] = 'An offset of elements returned by the criteria to skip';
$_lang['socialtools_list_prop_sortby'] = 'The field to sort by';
$_lang['socialtools_list_prop_sortdir'] = 'The direction to sort by';
$_lang['socialtools_list_prop_action'] = 'Output incoming or outgoing messages';
$_lang['socialtools_list_prop_outputSeparator'] = 'Output separator';
$_lang['socialtools_list_prop_totalVar'] = 'Placeholder for the total result values';



