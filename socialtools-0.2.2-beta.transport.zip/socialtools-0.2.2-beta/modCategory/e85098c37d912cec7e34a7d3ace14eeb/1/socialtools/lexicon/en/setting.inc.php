<?php
$_lang['area_socialtools_main'] = 'Main';
$_lang['area_socialtools_debug'] = 'Debug';
$_lang['setting_socialtools.css_use'] = 'Use CSS';
$_lang['setting_socialtools.css_use_desc'] = 'Register the default CSS';
$_lang['setting_socialtools.frontend_css'] = 'Path to CSS';
$_lang['setting_socialtools.frontend_css_desc'] = 'Relative path to the CSS file';
$_lang['setting_socialtools.gravatar_use'] = 'use Gravatar';
$_lang['setting_socialtools.gravatar_use_desc'] = 'Used to derive the avatar service Gravatar, if not, will use the "photo" of the user profile MODX';
$_lang['setting_socialtools.notify'] = 'Notification type';
$_lang['setting_socialtools.notify_desc'] = 'There are 2 types of notification, "alertify" and "jgrowl"';
$_lang['setting_socialtools.debug'] = 'Debug';
$_lang['setting_socialtools.deubg_desc'] = 'Debug mode allows you to send messages to self';
$_lang['setting_socialtools.is_read'] = 'Placeholder for unread messages';
$_lang['setting_socialtools.is_read_desc'] = 'Name placeholder to display unread messages';
