--------------------
SocialTools
--------------------
Author: Pekshev Alexsandr aka Asanvery <uokill@gmail.com>
--------------------

SocialTools - This Extra social composes CMS / CMF MODX Revolution. At this stage, with it you can send messages, read messages, get a list of incoming and outgoing messages.

Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/Asanvery/SocialTools/issues/